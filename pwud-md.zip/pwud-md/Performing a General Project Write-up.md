# Performing a General Project Write-up

**Author:** Dr. Trevor Michael Tomesh  
**Affiliation:** University of Wisconsin - River Falls  
**Email:** trevor.tomesh@uwrf.edu

## Abstract

This guide provides guidance on how to properly document and communicate your work. Whether you are working on a large term-project or a simple task, proper documentation is a necessity. This guide offers a template for your documentation. Abstracts should function as autonomous texts. Often, an abstract is presented by itself without the full paper, so the reader should be able to understand the research just by reading the abstract. Think of it as a preview or a brief summary. It helps the reader understand the purpose of a paper and should convey the main results, but the full article is needed for the methodology.

## Introduction

A background (or introduction) is necessary to provide the reader with any information they may need to understand your work. Depending on your target audience, you may need to go into more or less detail. The introduction is also a good place to discuss the motivation for your work.

### Motivation

In the motivation section, you want to inform the reader about your reasoning for carrying out the work. This serves a couple of purposes:

- To establish the importance of the work
- To motivate the reader to continue reading

While the motivation section is not always necessary, it is a good way to engage your audience and bring them around to your perspective.

### Background

The background may serve as a literature review. This is where you discuss related work by other researchers. For example, this document is created using Markdown, which is a lightweight markup language designed for creating formatted text. This section might be a good place to discuss the origins and uses of Markdown.

### Technical Background

If your work is highly technical and requires additional technical background, you may wish to include a "technical background" section.

## Methods

In this section, document precisely what your work procedure was. Provide all necessary details so anyone wishing to replicate or verify your work can do so. For example, this paper uses the IMRaD / hourglass model as shown in the figure below, which is a common organizational structure in journal articles. It includes an introduction, methods, results, and discussion sections. IMRaD is sandwiched between the abstract and the conclusion, acknowledgments, references, and supplementary data or appendix (collectively known as "CARS").

<img src="hourglass-model.png" alt="Image" width="500" height="auto" align = "left">

The hourglass model describes the literary flow of the body of your paper. Start with a broad focus and narrow it down. Once you've focused the reader on your specific topic/problem, you can draw them into your methodology (this section). The methodology and results will focus on your specific approach to the problem. The discussion will expand from the focus of your results and suggest the broader implications of your work. The hourglass model is useful for building up your reader's knowledge and interest.

## Results

Discuss the results of your efforts here. The results of this work are presented in this paper (a bit meta). This section is meant to be objective and to the point. Include any plots, charts, or images of what you have built.

## Discussion

In this section, discuss your results in detail. What worked? What didn't? How do you interpret the results? This section is where you make your case to the reader, so they might see and interpret your results as you do. You should also list the limitations of your methods. Be transparent about any difficulties or constraints. The goal is not to convince readers that your method is flawless, but to bring them to the same conclusions you have reached. Remember to use the hourglass model: expand the scope and get more general as you conclude.

## Conclusion

The conclusion is an opportunity to reiterate the important points of your work and discuss future research and unanswered questions.

## Appendix A - Code Listings

The appendix is for supplemental material that doesn't fit elsewhere in the document. This section includes code listings.

**Listing 1** is an example of rendering a series of cubes using the pyglet Python graphics utility. **Listing 2** is a Runge-Kutta 4 numeric integrator that approximates the solution to the differential equation \( $y'(t) = t \sqrt{y(t)}$ \).

### Drawing a Cube in pyglet

```python
import pyglet
from pyglet.gl import *

height = 800
width = 600
zs = 25 # zshift
win = pyglet.window.Window(height, width)

def square(x0, y0, l):
    glBegin(GL_LINES)
    glVertex2i(x0, y0)
    glVertex2i(x0, y0 + l)
    glVertex2i(x0, y0 + l)
    glVertex2i(x0 + l, y0 + l)
    glVertex2i(x0 + l, y0 + l)
    glVertex2i(x0 + l, y0)
    glVertex2i(x0 + l, y0)
    glVertex2i(x0, y0)
    glEnd()

def cube(x0, y0, l):
    glBegin(GL_LINES)
    glVertex2i(x0, y0)
    glVertex2i(x0, y0 + l)
    glVertex2i(x0, y0 + l)
    glVertex2i(x0 + l, y0 + l)
    glVertex2i(x0 + l, y0 + l)
    glVertex2i(x0 + l, y0)
    glVertex2i(x0 + l, y0)
    glVertex2i(x0, y0)
    glVertex2i(x0 + l, y0 + l)
    glVertex2i(x0 + l + zs, y0 + l + zs)
    glVertex2i(x0 + l, y0)
    glVertex2i(x0 + l + zs, y0 + zs)
    glVertex2i(x0, y0 + l)
    glVertex2i(x0 + zs, y0 + l + zs)
    glVertex2i(x0 + l + zs, y0 + l + zs)
    glVertex2i(x0 + zs, y0 + l + zs)
    glVertex2i(x0 + l + zs, y0 + l + zs)
    glVertex2i(x0 + l + zs, y0 + zs)
    glEnd()

def grid():
    sizey = height / 10
    sizex = width / 10
    for i in range(0, int(sizex)):
        for j in range(0, int(sizey)):
            square(i * 50, j * 50, 50)

@win.event
def on_draw():
    glClear(GL_COLOR_BUFFER_BIT)
    cube(400, 300, 50)
    cube(450, 300, 50)
    cube(550, 300, 50)
    cube(400, 350, 50)

pyglet.app.run()
```

### RK4 Solver in Python

```python
from math import sqrt

def rk4(f, x0, y0, x1, n):
    vx = [0] * (n + 1)
    vy = [0] * (n + 1)
    h = (x1 - x0) / float(n)
    vx[0] = x = x0
    vy[0] = y = y0
    for i in range(1, n + 1):
        k1 = h * f(x, y)
        k2 = h * f(x + 0.5 * h, y + 0.5 * k1)
        k3 = h * f(x + 0.5 * h, y + 0.5 * k2)
        k4 = h * f(x + h, y + k3)
        vx[i] = x = x0 + i * h
        vy[i] = y = y + (k1 + k2 + k2 + k3 + k3 + k4) / 6
    return vx, vy

def f(x, y):
    return x * sqrt(y)

vx, vy = rk4(f, 0, 1, 10, 100)
for x, y in list(zip(vx, vy))[::10]:
    print("%4.1f %10.5f %+12.4e" % (x, y, y - (4 + x * x) ** 2 / 16))
```

## Appendix B - Additional Images

![The Output of the Code Listing 1](cube-img.png)  
*The Output of the Code Listing 1*

<img src="arduino.png" alt="Image" width="300" height="auto" align="left">


*A random image of an Arduino.*

## Acknowledgments

I'd like to thank the reader for their attention.

## References

1. Donald E. Knuth (1986) *The TeX Book*, Addison-Wesley Professional.

